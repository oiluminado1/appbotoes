#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Importações de bibliotecas padrão
import sys      # Acesso a argumentos de linha de comando e funções do sistema
import os       # Operações do sistema de arquivos e ambiente

# Importações de componentes PyQt5
from PyQt5.QtWidgets import QApplication  # Classe principal para aplicações Qt
from PyQt5.QtCore import Qt               # Constantes e enumerações do Qt

# Importar componentes do projeto
# InterfaceGrafica: Gerencia a interface do usuário e os marcadores visíveis
from src.ui.interface_grafica import InterfaceGrafica

# GerenciadorConfiguracoes: Responsável pelo salvamento e carregamento das configurações
from src.gerenciadores.gerenciador_configuracoes import GerenciadorConfiguracoes

# GerenciadorTeclado: Captura eventos de teclado globalmente para acionar os marcadores
from src.gerenciadores.gerenciador_teclado import GerenciadorTeclado

def main():
    """Função principal que inicializa a aplicação.
    
    Esta função é o ponto de entrada do aplicativo e realiza as seguintes operações:
    1. Cria a instância principal da aplicação Qt
    2. Configura o comportamento da aplicação para continuar em segundo plano
    3. Inicializa os gerenciadores de configurações e teclado
    4. Carrega as configurações salvas anteriormente
    5. Cria e exibe a interface gráfica
    6. Inicia a captura de eventos de teclado em segundo plano
    7. Executa o loop principal da aplicação
    
    O fluxo de inicialização segue um padrão de dependências, onde cada componente
    é inicializado na ordem correta para garantir que todas as dependências estejam
    disponíveis quando necessárias.
    """
    # Criar a aplicação Qt - instância principal que gerencia o ciclo de eventos
    app = QApplication(sys.argv)
    
    # Configurar atributos globais da aplicação
    # Esta configuração é crucial para permitir que o aplicativo continue rodando
    # em segundo plano mesmo quando a janela principal é fechada
    app.setQuitOnLastWindowClosed(False)
    
    # Inicializar o gerenciador de configurações
    # Este componente é responsável por salvar e carregar as configurações dos marcadores
    # em um arquivo JSON, garantindo a persistência entre execuções do aplicativo
    gerenciador_config = GerenciadorConfiguracoes()
    
    # Carregar configurações salvas de execuções anteriores
    # Recupera a lista de marcadores previamente configurados pelo usuário
    configuracoes = gerenciador_config.carregar_configuracoes()
    
    # Inicializar a interface gráfica
    # Cria a janela principal e os controles para gerenciar os marcadores
    # Recebe o gerenciador de configurações e a lista de configurações carregadas
    interface = InterfaceGrafica(gerenciador_config, configuracoes)
    
    # Inicializar o gerenciador de teclado
    # Este componente monitora eventos de teclado globalmente para acionar os marcadores
    # quando suas teclas de atalho são pressionadas
    gerenciador_teclado = GerenciadorTeclado(interface)
    
    # Iniciar a captura de teclas em uma thread separada
    # Permite que o aplicativo responda a teclas de atalho mesmo quando não está em foco
    gerenciador_teclado.iniciar_captura()
    
    # Exibir a interface gráfica para o usuário
    interface.mostrar()
    
    # Executar o loop principal da aplicação
    # Este método bloqueia a execução até que a aplicação seja encerrada
    # O código de saída da aplicação é passado para sys.exit()
    sys.exit(app.exec_())

if __name__ == "__main__":
    # Este bloco garante que a função main() só será executada quando este script
    # for executado diretamente (não quando importado como um módulo)
    # É uma prática padrão em Python para scripts executáveis
    main()