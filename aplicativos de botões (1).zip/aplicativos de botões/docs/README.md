# Aplicativo de Botões Flutuantes

Este aplicativo permite criar botões flutuantes em segundo plano no computador. Os botões podem conter letras ou números e, quando pressionada a tecla correspondente, simulam um clique do mouse na posição onde estão localizados. Ideal para automatizar tarefas repetitivas que exigem cliques em posições específicas da tela.

## Funcionalidades

- **Botões Flutuantes Personalizáveis**: Crie botões associados a teclas de atalho específicas
- **Personalização Visual**: Configure cor e tamanho dos botões para melhor organização visual
- **Posicionamento Flexível**: Mova os botões arrastando-os para qualquer posição na tela
- **Simulação de Cliques**: Simule cliques do mouse (esquerdo ou direito) na posição do botão
- **Persistência de Configurações**: Salve e carregue configurações de botões entre sessões
- **Controle de Visibilidade**: Ajuste a opacidade global dos botões para minimizar distrações
- **Execução em Segundo Plano**: O aplicativo continua funcionando mesmo quando minimizado

## Arquitetura do Sistema

O aplicativo foi desenvolvido seguindo princípios de design orientado a objetos e padrões de projeto, resultando em uma estrutura modular, extensível e de fácil manutenção.

### Estrutura Modular

O código foi organizado em módulos separados, cada um com responsabilidades específicas:

#### Arquivos do Projeto

- `src/interfaces/interfaces.py`: Define interfaces abstratas e constantes do sistema
- `src/marcadores/marcador_base.py`: Implementa a classe base abstrata para todos os marcadores
- `src/marcadores/marcadores_especializados.py`: Implementa os tipos específicos de marcadores
- `src/gerenciadores/gerenciador_configuracoes.py`: Gerencia o salvamento e carregamento de configurações
- `src/gerenciadores/gerenciador_teclado.py`: Gerencia a captura de eventos de teclado globalmente
- `src/ui/interface_grafica.py`: Implementa a interface gráfica do usuário
- `aplicacao_principal.py`: Ponto de entrada da aplicação que integra todos os componentes

### Padrões de Design Implementados

#### Estrutura de Classes

1. **Interfaces Abstratas**:
   - `Arrastavel`: Define o comportamento para objetos que podem ser arrastados na tela
   - `Clicavel`: Define o comportamento para objetos que podem simular cliques do mouse

2. **Classe Base Abstrata**:
   - `MarcadorBase`: Implementa funcionalidades comuns a todos os marcadores como renderização, eventos de mouse e comportamento de arrasto

3. **Classes Derivadas**:
   - `MarcadorCliqueEsquerdo`: Especializada em simular cliques com o botão esquerdo do mouse
   - `MarcadorCliqueDireito`: Especializada em simular cliques com o botão direito do mouse

4. **Padrão Factory**:
   - `FabricaMarcadores`: Cria diferentes tipos de marcadores conforme necessário, encapsulando a lógica de instanciação

5. **Gerenciadores**:
   - `GerenciadorConfiguracoes`: Gerencia o salvamento e carregamento de configurações em formato JSON
   - `GerenciadorTeclado`: Gerencia a captura de eventos de teclado globalmente usando pynput
   - `InterfaceGrafica`: Gerencia a interface do usuário e os marcadores visíveis

### Fluxo de Dados e Comunicação

O aplicativo utiliza um fluxo de dados bem definido:

1. O `GerenciadorTeclado` captura eventos de teclado globalmente
2. Quando uma tecla associada a um marcador é pressionada, o gerenciador notifica a `InterfaceGrafica`
3. A `InterfaceGrafica` identifica o marcador correspondente e aciona seu método `simular_clique()`
4. O marcador executa o clique em uma thread separada (`ThreadClique`) para não bloquear a interface
5. As configurações são persistidas através do `GerenciadorConfiguracoes` em formato JSON

### Benefícios da Arquitetura

1. **Extensibilidade**: Novos tipos de marcadores podem ser adicionados facilmente criando novas classes derivadas
2. **Manutenção**: Código organizado e modular, com responsabilidades bem definidas
3. **Reutilização**: Comportamentos comuns são implementados uma única vez na classe base
4. **Flexibilidade**: Diferentes comportamentos podem ser combinados através de interfaces
5. **Legibilidade**: Nomes em português descritivos facilitam a compreensão do código
6. **Desacoplamento**: Os componentes são independentes e se comunicam através de interfaces bem definidas

## Requisitos

- Python 3.6 ou superior
- PyQt5: Framework para interface gráfica
- pynput: Biblioteca para captura de eventos de teclado globais
- pyautogui: Biblioteca para automação de mouse e teclado

## Instalação

1. Clone o repositório ou baixe os arquivos do projeto
2. Instale as dependências necessárias:

```
pip install -r requirements.txt
```

Ou instale manualmente as dependências:

```
pip install PyQt5 pynput pyautogui
```

## Como Executar

Execute o arquivo principal do aplicativo:

```
python aplicacao_principal.py
```

## Guia de Uso Detalhado

### Criando um Novo Marcador

1. Execute o aplicativo
2. Na janela principal, configure um novo marcador:
   - **Tecla de Atalho**: Selecione uma tecla que acionará o marcador (letras, números ou teclas especiais)
   - **Cor**: Clique no botão de cor para escolher uma cor personalizada para o marcador
   - **Tamanho**: Ajuste o controle deslizante para definir o tamanho do marcador (em pixels)
   - **Tipo de Clique**: Selecione "Clique Esquerdo" ou "Clique Direito" conforme a necessidade
   - Clique em "Adicionar Marcador" para criar o marcador com as configurações escolhidas

### Posicionando Marcadores

1. Após criar um marcador, ele aparecerá na tela com a tecla associada exibida
2. Clique e arraste o marcador para posicioná-lo no local desejado da tela
3. O marcador permanecerá nessa posição até que seja movido novamente

### Usando os Marcadores

1. Com os marcadores posicionados, pressione a tecla associada a qualquer momento
2. O aplicativo simulará um clique do mouse (esquerdo ou direito, conforme configurado) na posição do marcador
3. O mouse retornará automaticamente à posição original após o clique

### Gerenciando Marcadores

1. **Ajustar Visibilidade**: Use o controle deslizante de visibilidade para ajustar a opacidade de todos os marcadores
2. **Salvar Configuração**: Clique em "Salvar" para persistir a configuração atual dos marcadores
3. **Fechar a Interface**: Feche a janela principal para continuar com o aplicativo em segundo plano
4. **Acessar Novamente**: Clique com o botão direito no ícone da bandeja do sistema e selecione "Mostrar"
5. **Encerrar o Aplicativo**: Clique com o botão direito no ícone da bandeja e selecione "Sair"

## Casos de Uso Práticos

### Automação de Formulários

Posicione marcadores em campos de formulários frequentemente utilizados e use teclas de atalho para navegar rapidamente entre eles.

### Jogos e Aplicativos

Crie marcadores para botões ou áreas de clique em jogos e aplicativos, permitindo acionar funções rapidamente sem mover o mouse.

### Apresentações

Configure marcadores para controlar apresentações de slides, acionando botões de navegação sem precisar localizá-los visualmente.

### Fluxos de Trabalho

Automatize sequências de cliques em aplicativos de produtividade, criando um fluxo de trabalho mais eficiente com teclas de atalho.

## Solução de Problemas

### Marcadores Não Aparecem

- Verifique se o controle de visibilidade não está no mínimo
- Certifique-se de que não há conflitos com outros aplicativos que capturam teclas globalmente

### Cliques Não Funcionam

- Verifique se o aplicativo tem as permissões necessárias para controlar o mouse
- Em alguns sistemas, pode ser necessário executar o aplicativo como administrador

### Conflitos de Teclas

- Evite usar teclas que já são utilizadas como atalhos por outros aplicativos
- Prefira combinações de teclas menos comuns para evitar conflitos

## Contribuições

Contribuições são bem-vindas! Sinta-se à vontade para abrir issues ou enviar pull requests com melhorias e correções.

## Licença

Este projeto está licenciado sob a licença MIT - veja o arquivo LICENSE para detalhes.