# Importações de bibliotecas PyQt5 necessárias para definição de interfaces
from PyQt5.QtCore import QPoint, pyqtSignal  # QPoint para coordenadas, pyqtSignal para sinais personalizados

# Constantes para identificar eventos de mouse
# Estas constantes são usadas em todo o sistema para identificar de forma consistente
# os diferentes tipos de eventos de mouse que podem ser processados pelos marcadores
BOTAO_ESQUERDO = 1  # Constante para identificar eventos do botão esquerdo do mouse
BOTAO_DIREITO = 3   # Constante para identificar eventos do botão direito do mouse

# Interface para comportamento de arrasto (usando mixin em vez de ABC)
class Arrastavel:
    """Interface que define o comportamento para objetos que podem ser arrastados na tela.
    
    Esta interface define os métodos necessários para implementar o comportamento de
    arrastar e soltar (drag and drop) em objetos gráficos. Ao invés de usar ABC
    (Abstract Base Class), utiliza-se o conceito de mixin para permitir herança múltipla
    e composição de comportamentos.
    
    As classes que implementam esta interface devem fornecer funcionalidade para:
    - Iniciar o processo de arrasto quando o usuário clica no objeto
    - Atualizar a posição do objeto conforme o mouse é movido
    - Finalizar o arrasto quando o botão do mouse é solto
    """
    
    def iniciar_arrasto(self, posicao):
        """Inicia o processo de arrasto do objeto.
        
        Este método é chamado quando o usuário pressiona o botão do mouse sobre o objeto,
        iniciando a operação de arrasto. Deve armazenar a posição inicial e quaisquer
        outros dados necessários para calcular o deslocamento durante o arrasto.
        
        Args:
            posicao (QPoint): Posição inicial do clique em coordenadas relativas ao objeto
        """
        raise NotImplementedError("Método iniciar_arrasto deve ser implementado pelas subclasses")
    
    def arrastar(self, posicao):
        """Arrasta o objeto para a nova posição.
        
        Este método é chamado continuamente enquanto o usuário move o mouse com o botão
        pressionado. Deve calcular a nova posição do objeto com base na posição atual
        do mouse e na posição inicial do clique.
        
        Args:
            posicao (QPoint): Nova posição do mouse em coordenadas globais da tela
        """
        raise NotImplementedError("Método arrastar deve ser implementado pelas subclasses")
    
    def finalizar_arrasto(self):
        """Finaliza o processo de arrasto do objeto.
        
        Este método é chamado quando o usuário solta o botão do mouse, concluindo
        a operação de arrasto. Deve limpar quaisquer estados temporários usados
        durante o processo de arrasto e confirmar a nova posição do objeto.
        """
        raise NotImplementedError("Método finalizar_arrasto deve ser implementado pelas subclasses")

# Interface para comportamento de clique
class Clicavel:
    """Interface que define o comportamento para objetos que podem simular cliques do mouse.
    
    Esta interface define os métodos necessários para implementar o comportamento de
    simulação de cliques do mouse. Os objetos que implementam esta interface podem
    ser acionados por teclas de atalho para simular cliques do mouse em suas posições,
    sem que o usuário precise mover o cursor manualmente.
    
    As classes que implementam esta interface devem fornecer funcionalidade para:
    - Simular cliques do mouse na posição do objeto
    - Vincular callbacks a diferentes tipos de eventos de mouse
    """
    
    def simular_clique(self):
        """Simula um clique do mouse na posição do objeto.
        
        Este método deve implementar a lógica para simular um clique do mouse
        na posição atual do objeto. A implementação típica move o cursor do mouse
        para a posição do objeto, executa o clique e retorna o cursor à posição original.
        
        A simulação deve ser realizada em uma thread separada para evitar bloquear
        a interface do usuário durante a operação.
        
        Returns:
            bool: True se o clique foi simulado com sucesso, False caso contrário
        """
        raise NotImplementedError("Método simular_clique deve ser implementado pelas subclasses")
    
    def bind(self, tipo_evento, callback):
        """Vincula um callback a um tipo específico de evento.
        
        Este método permite associar funções de callback a diferentes tipos de eventos
        de mouse, permitindo que o objeto responda de maneiras diferentes a cliques
        do botão esquerdo e direito.
        
        Args:
            tipo_evento (int): Tipo de evento (BOTAO_ESQUERDO ou BOTAO_DIREITO)
            callback (function): Função a ser chamada quando o evento ocorrer
                A função callback deve aceitar a posição do evento como parâmetro
        
        Returns:
            bool: True se o callback foi vinculado com sucesso, False caso contrário
        """
        raise NotImplementedError("Método bind deve ser implementado pelas subclasses")