# Importações de bibliotecas PyQt5 para widgets e interface gráfica
from PyQt5.QtWidgets import QWidget, QLabel
from PyQt5.QtCore import Qt, QPoint, pyqtSignal, QTimer, QThread
from PyQt5.QtGui import QFont, QColor

# Importações de bibliotecas padrão e utilitárias
import weakref  # Para referências fracas que evitam vazamentos de memória
import traceback  # Para rastreamento de erros
import pyautogui  # Para automação de mouse
from abc import ABC, abstractmethod  # Para classes abstratas

# Importar interfaces e constantes definidas no projeto
from src.interfaces.interfaces import Arrastavel, Clicavel, BOTAO_ESQUERDO, BOTAO_DIREITO

# Classe para executar cliques em uma thread separada
class ThreadClique(QThread):
    """Thread dedicada para executar cliques do mouse em segundo plano.
    
    Evita bloqueios na interface do usuário durante a simulação de cliques.
    Executa a movimentação do mouse, o clique e o retorno à posição original
    em uma thread separada para não congelar a interface gráfica durante
    estas operações.    
    """
    # Sinal emitido quando o clique é concluído
    clique_concluido = pyqtSignal(bool)
    
    def __init__(self, posicao, botao):
        """Inicializa a thread de clique.
        
        Configura os parâmetros necessários para a simulação do clique
        e armazena a posição atual do mouse para restaurá-la após o clique.
        
        Args:
            posicao (tuple): Coordenadas (x, y) para o clique na tela
            botao (str): Botão do mouse a ser clicado ("left" ou "right")
        """
        super().__init__()
        self.posicao = posicao
        self.botao = botao
        self.pos_original = pyautogui.position()
    
    def run(self):
        """Executa a simulação do clique em uma thread separada.
        
        Este método é chamado automaticamente quando a thread é iniciada.
        Realiza a seguinte sequência de ações:
        1. Desativa o failsafe do pyautogui temporariamente
        2. Move o mouse para a posição do marcador
        3. Executa o clique com o botão especificado
        4. Retorna o mouse à posição original
        5. Reativa o failsafe do pyautogui
        6. Emite um sinal indicando o resultado da operação
        
        Em caso de erro, captura a exceção, exibe informações de depuração
        e emite um sinal de falha.
        """
        try:
            # Desativar o failsafe do pyautogui para evitar interrupções
            failsafe_original = pyautogui.FAILSAFE
            pyautogui.FAILSAFE = False
            
            # Mover o mouse para a posição do marcador, clicar e retornar à posição original
            pyautogui.moveTo(self.posicao[0], self.posicao[1], duration=0.05)
            pyautogui.click(button=self.botao)
            pyautogui.moveTo(self.pos_original.x, self.pos_original.y, duration=0.05)
            
            # Restaurar o failsafe
            pyautogui.FAILSAFE = failsafe_original
            
            # Emitir sinal de sucesso
            self.clique_concluido.emit(True)
        except Exception as e:
            print(f"Erro ao simular clique: {e}")
            traceback.print_exc()
            # Emitir sinal de falha
            self.clique_concluido.emit(False)

# Classe base abstrata para marcadores
class MarcadorBase(QWidget, Arrastavel, Clicavel):
    """Classe base abstrata para todos os tipos de marcadores.
    
    Implementa funcionalidades comuns como aparência, arrasto e eventos de mouse.
    As classes derivadas devem implementar o método simular_clique().
    
    Esta classe serve como base para todos os tipos de marcadores no sistema,
    fornecendo implementações para funcionalidades compartilhadas como:
    - Renderização visual do marcador na tela
    - Funcionalidade de arrastar e soltar
    - Gerenciamento de eventos de mouse
    - Controle de visibilidade e aparência
    - Mecanismo base para simulação de cliques
    
    A classe implementa as interfaces Arrastavel e Clicavel definidas no módulo
    de interfaces, garantindo que todos os marcadores tenham um comportamento
    consistente.    
    """
    # Sinal personalizado para eventos de mouse
    mouse_event_signal = pyqtSignal(int, QPoint)  # tipo de evento, posição
    
    # Tempo mínimo entre eventos de mouse (em milissegundos)
    TEMPO_MINIMO_ENTRE_EVENTOS = 50
    
    def __init__(self, tecla, posicao, cor="#3498db", tamanho=30, visibilidade=0.5):
        """Inicializa o marcador base com as configurações especificadas.
        
        Args:
            tecla (str): Tecla de atalho associada ao marcador
            posicao (list): Coordenadas [x, y] iniciais do marcador
            cor (str): Cor do marcador em formato hexadecimal
            tamanho (int): Tamanho do marcador em pixels
            visibilidade (float): Nível de opacidade (0.0 a 1.0)
        """
        super().__init__()
        self.tecla = tecla.lower()
        self.posicao_original = posicao
        self.tamanho = tamanho
        self.cor = cor
        self.visibilidade = visibilidade
        self.callbacks = weakref.WeakValueDictionary()  # Usar referências fracas para evitar vazamentos de memória
        self.arrasto_ativo = False
        self.offset_arrasto = QPoint(0, 0)
        
        # Cache para posição central (otimização)
        self._centro_cache = None
        self._ultima_atualizacao_centro = 0
        
        # Timer para limitar a frequência de eventos de mouse
        self._ultimo_evento_mouse = 0
        self._timer_eventos = QTimer(self)
        self._timer_eventos.setSingleShot(True)
        self._timer_eventos.timeout.connect(self._processar_evento_pendente)
        self._evento_pendente = None
        
        # Configurar a aparência do marcador
        self.setGeometry(posicao[0], posicao[1], tamanho, tamanho)
        self.setStyleSheet(f"background-color: {cor}; border-radius: {tamanho//2}px;")
        
        # Ajustar flags para garantir que o marcador fique sobre outras janelas
        self.setWindowFlags(Qt.WindowStaysOnTopHint | Qt.FramelessWindowHint | Qt.Tool)
        
        # Permitir eventos de mouse
        self.setMouseTracking(True)
        
        # Adicionar texto (tecla) ao centro do marcador
        self.label_tecla = QLabel(self)
        self.label_tecla.setText(tecla.upper())
        self.label_tecla.setAlignment(Qt.AlignCenter)
        self.label_tecla.setGeometry(0, 0, tamanho, tamanho)
        self.label_tecla.setFont(QFont("Arial", tamanho // 3, QFont.Bold))
        self.label_tecla.setStyleSheet("background-color: transparent; color: white;")
        
        # Configurar opacidade
        self.setWindowOpacity(visibilidade)
        
        # Conectar o sinal personalizado ao método de processamento
        self.mouse_event_signal.connect(self._enfileirar_evento_mouse)
    
    def mousePressEvent(self, event):
        """Manipula o evento de pressionar o botão do mouse.
        
        Args:
            event (QMouseEvent): Evento de mouse
        """
        if event.button() == Qt.LeftButton:
            self.iniciar_arrasto(event.pos())
        elif event.button() == Qt.RightButton:
            # Emitir sinal para evento de clique direito
            self.mouse_event_signal.emit(BOTAO_DIREITO, self.pos())
    
    def mouseMoveEvent(self, event):
        """Manipula o evento de mover o mouse.
        
        Args:
            event (QMouseEvent): Evento de mouse
        """
        if self.arrasto_ativo:
            self.arrastar(event.globalPos())
    
    def mouseReleaseEvent(self, event):
        """Manipula o evento de soltar o botão do mouse.
        
        Args:
            event (QMouseEvent): Evento de mouse
        """
        if event.button() == Qt.LeftButton and self.arrasto_ativo:
            self.finalizar_arrasto()
    
    def iniciar_arrasto(self, posicao):
        """Inicia o processo de arrasto do marcador.
        
        Args:
            posicao (QPoint): Posição inicial do clique
        """
        self.arrasto_ativo = True
        self.offset_arrasto = posicao
    
    def arrastar(self, posicao):
        """Arrasta o marcador para a nova posição.
        
        Args:
            posicao (QPoint): Nova posição do mouse
        """
        self.move(posicao - self.offset_arrasto)
        # Atualizar a posição original para salvar posteriormente
        self.posicao_original = [self.pos().x(), self.pos().y()]
        
        # Invalidar o cache da posição central
        self._centro_cache = None
    
    def finalizar_arrasto(self):
        """Finaliza o processo de arrasto do marcador."""
        self.arrasto_ativo = False
    
    def atualizar_visibilidade(self, valor):
        """Atualiza a visibilidade (opacidade) do marcador.
        
        Args:
            valor (float): Novo valor de opacidade (0.0 a 1.0)
        """
        self.visibilidade = valor
        self.setWindowOpacity(valor)
    
    def bind(self, tipo_evento, callback):
        """Vincula um callback a um tipo específico de evento.
        
        Args:
            tipo_evento (int): Tipo de evento (BOTAO_ESQUERDO ou BOTAO_DIREITO)
            callback (function): Função a ser chamada quando o evento ocorrer
        """
        self.callbacks[tipo_evento] = callback
    
    def _enfileirar_evento_mouse(self, tipo_evento, posicao):
        """Enfileira um evento de mouse para processamento posterior.
        
        Isso evita processamento excessivo de eventos em sequência rápida.
        
        Args:
            tipo_evento (int): Tipo de evento (BOTAO_ESQUERDO ou BOTAO_DIREITO)
            posicao (QPoint): Posição do evento
        """
        tempo_atual = self._timer_eventos.remainingTime()
        
        # Armazenar o evento mais recente
        self._evento_pendente = (tipo_evento, posicao)
        
        # Se o timer não estiver ativo, iniciar com o tempo mínimo
        if not self._timer_eventos.isActive():
            self._timer_eventos.start(self.TEMPO_MINIMO_ENTRE_EVENTOS)
    
    def _processar_evento_pendente(self):
        """Processa o evento de mouse pendente mais recente."""
        if self._evento_pendente:
            tipo_evento, posicao = self._evento_pendente
            self._evento_pendente = None
            
            # Chamar o callback apropriado se existir
            if tipo_evento in self.callbacks:
                try:
                    callback = self.callbacks[tipo_evento]
                    if callback:
                        callback(posicao)
                except (KeyError, TypeError):
                    # Lidar com callbacks que foram removidos ou são inválidos
                    pass
    
    def obter_centro(self):
        """Retorna o centro do marcador de forma otimizada.
        
        Returns:
            tuple: Coordenadas (x, y) do centro do marcador
        """
        # Usar cache se disponível e válido
        if self._centro_cache is not None:
            return self._centro_cache
        
        # Calcular o centro
        pos_x = self.pos().x() + self.tamanho // 2
        pos_y = self.pos().y() + self.tamanho // 2
        
        # Armazenar no cache
        self._centro_cache = (pos_x, pos_y)
        return self._centro_cache
        
    def _executar_clique(self, botao):
        """Executa um clique do mouse na posição do marcador.
        
        Args:
            botao (str): Botão do mouse a ser clicado ("left" ou "right")
            
        Returns:
            bool: True se o clique foi bem-sucedido, False caso contrário
        """
        try:
            # Obter o centro do marcador usando o método otimizado
            pos_x, pos_y = self.obter_centro()
            
            # Criar e iniciar a thread de clique
            self.thread_clique = ThreadClique((pos_x, pos_y), botao)
            
            # Conectar o sinal de conclusão
            self.thread_clique.clique_concluido.connect(self._clique_finalizado)
            
            # Iniciar a thread
            self.thread_clique.start()
            
            return True
        except Exception as e:
            print(f"Erro ao iniciar simulação de clique: {e}")
            traceback.print_exc()
            return False
    
    def _clique_finalizado(self, sucesso):
        """Callback chamado quando a thread de clique é concluída.
        
        Args:
            sucesso (bool): Indica se o clique foi bem-sucedido
        """
        if not sucesso:
            print(f"Falha na simulação de clique do marcador {self.tecla}")
        
        # Limpar a referência à thread
        self.thread_clique = None
        return self._centro_cache
    
    @abstractmethod
    def simular_clique(self):
        """Método abstrato que deve ser implementado pelas classes derivadas.
        
        Deve simular um clique do mouse na posição do marcador.
        """
        pass