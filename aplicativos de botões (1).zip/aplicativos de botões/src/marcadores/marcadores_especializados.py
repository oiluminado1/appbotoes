# Importar a classe base e a classe ThreadClique do módulo base de marcadores
# MarcadorBase: Classe abstrata que define o comportamento comum a todos os marcadores
# ThreadClique: Classe que implementa a simulação de cliques em uma thread separada
from src.marcadores.marcador_base import MarcadorBase, ThreadClique

# Classe para marcador de clique esquerdo
class MarcadorCliqueEsquerdo(MarcadorBase):
    """Marcador que simula um clique com o botão esquerdo do mouse.
    
    Esta classe especializada implementa um marcador que, quando acionado,
    simula um clique com o botão esquerdo do mouse na posição onde o marcador
    está localizado na tela. É útil para automatizar ações como selecionar
    itens, clicar em botões ou links, etc.
    """
    
    def __init__(self, tecla, posicao, cor="#3498db", tamanho=30, visibilidade=0.5):
        """Inicializa um marcador de clique esquerdo.
        
        Configura um marcador com as propriedades especificadas e define o botão
        do mouse como "left" para simular cliques com o botão esquerdo. A cor
        padrão é azul (#3498db) para diferenciar visualmente dos marcadores de
        clique direito.
        
        Args:
            tecla (str): Tecla de atalho associada ao marcador, usada para acioná-lo
            posicao (list): Coordenadas [x, y] iniciais do marcador na tela
            cor (str): Cor do marcador em formato hexadecimal (ex: "#3498db" para azul)
            tamanho (int): Tamanho do marcador em pixels (diâmetro)
            visibilidade (float): Nível de opacidade do marcador (0.0 a 1.0)
        """
        super().__init__(tecla, posicao, cor, tamanho, visibilidade)
        self.botao_mouse = "left"
        self.thread_clique = None
    
    def simular_clique(self):
        """Simula um clique com o botão esquerdo do mouse na posição do marcador.
        
        Implementa o método abstrato da classe base, delegando a execução do clique
        para o método _executar_clique com o botão configurado como "left".
        
        Returns:
            bool: True se o clique foi iniciado com sucesso, False caso contrário
        """
        return self._executar_clique(self.botao_mouse)

# Classe para marcador de clique direito
class MarcadorCliqueDireito(MarcadorBase):
    """Marcador que simula um clique com o botão direito do mouse.
    
    Esta classe especializada implementa um marcador que, quando acionado,
    simula um clique com o botão direito do mouse na posição onde o marcador
    está localizado na tela. É útil para automatizar ações como abrir menus
    de contexto, opções alternativas, etc.
    """
    
    def __init__(self, tecla, posicao, cor="#e74c3c", tamanho=30, visibilidade=0.5):
        """Inicializa um marcador de clique direito.
        
        Configura um marcador com as propriedades especificadas e define o botão
        do mouse como "right" para simular cliques com o botão direito. A cor
        padrão é vermelha (#e74c3c) para diferenciar visualmente dos marcadores de
        clique esquerdo.
        
        Args:
            tecla (str): Tecla de atalho associada ao marcador, usada para acioná-lo
            posicao (list): Coordenadas [x, y] iniciais do marcador na tela
            cor (str): Cor do marcador em formato hexadecimal (ex: "#e74c3c" para vermelho)
            tamanho (int): Tamanho do marcador em pixels (diâmetro)
            visibilidade (float): Nível de opacidade do marcador (0.0 a 1.0)
        """
        super().__init__(tecla, posicao, cor, tamanho, visibilidade)
        self.botao_mouse = "right"
        self.thread_clique = None
    
    def simular_clique(self):
        """Simula um clique com o botão direito do mouse na posição do marcador.
        
        Implementa o método abstrato da classe base, delegando a execução do clique
        para o método _executar_clique com o botão configurado como "right".
        
        Returns:
            bool: True se o clique foi iniciado com sucesso, False caso contrário
        """
        return self._executar_clique(self.botao_mouse)

# Classe para fábrica de marcadores
class FabricaMarcadores:
    """Fábrica para criar diferentes tipos de marcadores.
    
    Implementa o padrão Factory para criar marcadores especializados
    de acordo com o tipo de botão do mouse especificado. Esta classe
    centraliza a criação de marcadores, facilitando a adição de novos
    tipos no futuro sem modificar o código cliente.
    
    O padrão Factory é utilizado para encapsular a lógica de criação
    dos diferentes tipos de marcadores, tornando o código mais modular
    e extensível.
    """
    
    @staticmethod
    def criar_marcador(tipo_botao, tecla, posicao, cor="#3498db", tamanho=30, visibilidade=0.5):
        """Cria um marcador do tipo especificado.
        
        Método de fábrica que instancia e retorna o tipo apropriado de marcador
        com base no tipo de botão especificado. Se o tipo for "right", cria um
        marcador de clique direito; caso contrário, cria um marcador de clique
        esquerdo por padrão.
        
        Este método centraliza a lógica de criação, facilitando a adição de
        novos tipos de marcadores no futuro sem modificar o código cliente.
        
        Args:
            tipo_botao (str): Tipo de botão do mouse ("left" ou "right")
            tecla (str): Tecla de atalho associada ao marcador
            posicao (list): Coordenadas [x, y] iniciais do marcador na tela
            cor (str): Cor do marcador em formato hexadecimal
            tamanho (int): Tamanho do marcador em pixels (diâmetro)
            visibilidade (float): Nível de opacidade do marcador (0.0 a 1.0)
            
        Returns:
            MarcadorBase: Uma instância de uma classe derivada de MarcadorBase
                (MarcadorCliqueEsquerdo ou MarcadorCliqueDireito)
        """
        if tipo_botao == "right":
            return MarcadorCliqueDireito(tecla, posicao, cor, tamanho, visibilidade)
        else:  # default: left
            return MarcadorCliqueEsquerdo(tecla, posicao, cor, tamanho, visibilidade)