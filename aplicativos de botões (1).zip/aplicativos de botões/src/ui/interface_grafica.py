#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Importações de bibliotecas PyQt5 para interface gráfica
from PyQt5.QtWidgets import QMainWindow, QSystemTrayIcon, QMenu, QAction, QVBoxLayout, QHBoxLayout, QWidget, QPushButton, QLabel, QComboBox, QColorDialog, QSlider, QMessageBox
from PyQt5.QtGui import QIcon, QColor  # Para ícones e cores
from PyQt5.QtCore import Qt, QSize  # Para constantes e dimensionamento

# Importações de bibliotecas padrão
import os
import sys

# Importar componentes do projeto
# Classes de marcadores que serão gerenciadas pela interface
from src.marcadores.marcador_base import MarcadorBase
from src.marcadores.marcadores_especializados import MarcadorCliqueEsquerdo, MarcadorCliqueDireito

class InterfaceGrafica(QMainWindow):
    """Classe responsável pela interface gráfica da aplicação.
    
    Implementa a janela principal, o ícone na bandeja do sistema e os controles
    para gerenciar os marcadores. Esta classe serve como ponto central de interação
    do usuário com o aplicativo, permitindo criar, configurar e gerenciar os
    marcadores de clique na tela.
    
    A interface é composta por:
    - Uma janela principal com controles para criar e gerenciar marcadores
    - Um ícone na bandeja do sistema para acesso rápido
    - Controles para personalizar a aparência e comportamento dos marcadores
    """
    
    def __init__(self, gerenciador_config, configuracoes=None):
        """Inicializa a interface gráfica.
        
        Configura a janela principal, cria o ícone na bandeja do sistema,
        inicializa a interface de usuário e carrega os marcadores salvos
        anteriormente, se existirem.
        
        Args:
            gerenciador_config (GerenciadorConfiguracoes): Gerenciador responsável pelo
                salvamento e carregamento das configurações dos marcadores
            configuracoes (list, optional): Lista de dicionários contendo as configurações
                dos marcadores previamente salvos (tecla, tipo, cor, tamanho, etc.)
        """
        super().__init__()
        
        self.gerenciador_config = gerenciador_config
        self.marcadores = []
        
        # Configurar a janela principal
        self.setWindowTitle("Aplicativo de Botões Flutuantes")
        self.setGeometry(100, 100, 400, 300)
        
        # Criar o ícone na bandeja do sistema
        self.criar_icone_bandeja()
        
        # Configurar a interface
        self.configurar_interface()
        
        # Carregar marcadores salvos
        if configuracoes:
            self.carregar_marcadores(configuracoes)
    
    def criar_icone_bandeja(self):
        """Cria o ícone na bandeja do sistema com menu de contexto.
        
        Adiciona um ícone na área de notificação (bandeja do sistema) que permite
        ao usuário interagir com o aplicativo mesmo quando a janela principal
        está fechada. O menu de contexto oferece opções para mostrar a janela
        principal ou sair do aplicativo.
        """
        # Criar o ícone
        self.tray_icon = QSystemTrayIcon(self)
        
        # Usar um ícone padrão do sistema se não tivermos um personalizado
        self.tray_icon.setIcon(QIcon.fromTheme("applications-system"))
        
        # Criar o menu de contexto
        tray_menu = QMenu()
        
        # Adicionar ações ao menu
        mostrar_acao = QAction("Mostrar", self)
        mostrar_acao.triggered.connect(self.mostrar)
        
        sair_acao = QAction("Sair", self)
        sair_acao.triggered.connect(self.sair)
        
        tray_menu.addAction(mostrar_acao)
        tray_menu.addSeparator()
        tray_menu.addAction(sair_acao)
        
        # Definir o menu para o ícone
        self.tray_icon.setContextMenu(tray_menu)
        
        # Mostrar o ícone
        self.tray_icon.show()
    
    def configurar_interface(self):
        """Configura os elementos da interface gráfica.
        
        Cria e organiza todos os widgets da interface do usuário, incluindo:
        - Seção para criação de novos marcadores com controles para:
          * Seleção de tecla de atalho
          * Escolha do tipo de marcador (clique esquerdo/direito)
          * Seleção de cor
          * Ajuste de tamanho e visibilidade
        - Lista de marcadores existentes com opções para removê-los
        - Botões para salvar configurações e fechar a janela
        
        A interface utiliza layouts verticais e horizontais para organizar
        os elementos de forma responsiva e intuitiva.
        """
        # Widget central
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # Layout principal
        layout_principal = QVBoxLayout(central_widget)
        
        # Seção de criação de marcadores
        layout_principal.addWidget(QLabel("<h2>Criar Novo Marcador</h2>"))
        
        # Layout para configurações do novo marcador
        layout_novo = QHBoxLayout()
        
        # Tecla de atalho
        layout_novo.addWidget(QLabel("Tecla:"))
        self.tecla_input = QComboBox()
        self.tecla_input.addItems([chr(i) for i in range(97, 123)])  # a-z
        layout_novo.addWidget(self.tecla_input)
        
        # Tipo de marcador
        layout_novo.addWidget(QLabel("Tipo:"))
        self.tipo_input = QComboBox()
        self.tipo_input.addItems(["Clique Esquerdo", "Clique Direito"])
        layout_novo.addWidget(self.tipo_input)
        
        # Cor
        self.cor_atual = "#3498db"  # Cor padrão
        self.botao_cor = QPushButton()
        self.botao_cor.setFixedSize(24, 24)
        self.botao_cor.setStyleSheet(f"background-color: {self.cor_atual};")
        self.botao_cor.clicked.connect(self.selecionar_cor)
        layout_novo.addWidget(QLabel("Cor:"))
        layout_novo.addWidget(self.botao_cor)
        
        # Tamanho
        layout_novo.addWidget(QLabel("Tamanho:"))
        self.tamanho_slider = QSlider(Qt.Horizontal)
        self.tamanho_slider.setRange(20, 60)
        self.tamanho_slider.setValue(30)
        layout_novo.addWidget(self.tamanho_slider)
        
        # Visibilidade
        layout_novo.addWidget(QLabel("Visibilidade:"))
        self.visibilidade_slider = QSlider(Qt.Horizontal)
        self.visibilidade_slider.setRange(1, 10)
        self.visibilidade_slider.setValue(5)
        layout_novo.addWidget(self.visibilidade_slider)
        
        layout_principal.addLayout(layout_novo)
        
        # Botão para criar marcador
        botao_criar = QPushButton("Criar Marcador")
        botao_criar.clicked.connect(self.criar_marcador)
        layout_principal.addWidget(botao_criar)
        
        # Seção de marcadores existentes
        layout_principal.addWidget(QLabel("<h2>Marcadores Existentes</h2>"))
        
        # Layout para lista de marcadores
        self.layout_lista = QVBoxLayout()
        layout_principal.addLayout(self.layout_lista)
        
        # Botões de ação
        layout_botoes = QHBoxLayout()
        
        botao_salvar = QPushButton("Salvar Configurações")
        botao_salvar.clicked.connect(self.salvar_configuracoes)
        layout_botoes.addWidget(botao_salvar)
        
        botao_fechar = QPushButton("Fechar")
        botao_fechar.clicked.connect(self.hide)
        layout_botoes.addWidget(botao_fechar)
        
        layout_principal.addLayout(layout_botoes)
    
    def selecionar_cor(self):
        """Abre um diálogo para selecionar a cor do marcador.
        
        Exibe o seletor de cores padrão do sistema, permitindo ao usuário
        escolher uma cor personalizada para o marcador. A cor selecionada
        é armazenada e o botão de cor na interface é atualizado para
        refletir a escolha.
        """
        cor = QColorDialog.getColor(QColor(self.cor_atual), self, "Selecionar Cor do Marcador")
        if cor.isValid():
            self.cor_atual = cor.name()
            self.botao_cor.setStyleSheet(f"background-color: {self.cor_atual};")
    
    def criar_marcador(self):
        """Cria um novo marcador com as configurações especificadas.
        
        Obtém os valores dos controles da interface (tecla, tipo, cor, tamanho
        e visibilidade) e cria um novo marcador com essas configurações.
        Verifica se a tecla escolhida já está em uso por outro marcador e,
        caso não esteja, cria o marcador do tipo apropriado, adiciona-o à
        lista de marcadores e atualiza a interface.
        
        O marcador é posicionado inicialmente em uma posição padrão (100,100)
        na tela e pode ser movido pelo usuário posteriormente.
        """
        tecla = self.tecla_input.currentText().lower()
        tipo = self.tipo_input.currentText()
        cor = self.cor_atual
        tamanho = self.tamanho_slider.value()
        visibilidade = self.visibilidade_slider.value() / 10.0
        
        # Verificar se a tecla já está em uso
        for marcador in self.marcadores:
            if marcador.tecla == tecla:
                QMessageBox.warning(self, "Tecla em Uso", f"A tecla '{tecla}' já está associada a um marcador.")
                return
        
        # Criar o marcador apropriado
        if tipo == "Clique Esquerdo":
            marcador = MarcadorCliqueEsquerdo(tecla, [100, 100], cor, tamanho, visibilidade)
        else:  # Clique Direito
            marcador = MarcadorCliqueDireito(tecla, [100, 100], cor, tamanho, visibilidade)
        
        # Adicionar à lista de marcadores
        self.marcadores.append(marcador)
        
        # Mostrar o marcador
        marcador.show()
        
        # Atualizar a lista na interface
        self.atualizar_lista_marcadores()
    
    def atualizar_lista_marcadores(self):
        """Atualiza a lista de marcadores na interface.
        
        Reconstrói a lista visual de marcadores na interface, removendo todos
        os itens existentes e adicionando um item para cada marcador atual.
        Cada item na lista mostra informações sobre o marcador (tecla e tipo)
        e inclui um botão para removê-lo.
        
        Este método é chamado sempre que um marcador é adicionado ou removido
        para manter a interface sincronizada com o estado atual dos marcadores.
        """
        # Limpar o layout atual
        while self.layout_lista.count():
            item = self.layout_lista.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        
        # Adicionar cada marcador à lista
        for marcador in self.marcadores:
            layout_item = QHBoxLayout()
            
            # Informações do marcador
            tipo = "Clique Esquerdo" if isinstance(marcador, MarcadorCliqueEsquerdo) else "Clique Direito"
            info = f"Tecla: {marcador.tecla.upper()} | Tipo: {tipo}"
            layout_item.addWidget(QLabel(info))
            
            # Botão para remover
            botao_remover = QPushButton("Remover")
            botao_remover.setProperty("tecla", marcador.tecla)  # Armazenar a tecla como propriedade
            botao_remover.clicked.connect(lambda checked, t=marcador.tecla: self.remover_marcador(t))
            layout_item.addWidget(botao_remover)
            
            self.layout_lista.addLayout(layout_item)
    
    def remover_marcador(self, tecla):
        """Remove um marcador da lista.
        
        Localiza o marcador associado à tecla especificada, oculta-o da tela
        e o remove da lista de marcadores. Em seguida, atualiza a interface
        para refletir a remoção.
        
        Args:
            tecla (str): Tecla associada ao marcador a ser removido. Esta é a
                chave única que identifica cada marcador no sistema.
        """
        for i, marcador in enumerate(self.marcadores):
            if marcador.tecla == tecla:
                # Esconder e remover o marcador
                marcador.hide()
                self.marcadores.pop(i)
                break
        
        # Atualizar a lista na interface
        self.atualizar_lista_marcadores()
    
    def carregar_marcadores(self, configuracoes):
        """Carrega os marcadores a partir das configurações salvas.
        
        Recria os marcadores com base nas configurações carregadas do arquivo
        de configuração. Para cada configuração, extrai os parâmetros necessários
        (tecla, tipo, cor, tamanho, visibilidade e posição) e cria um marcador
        do tipo apropriado com essas configurações. Os marcadores criados são
        adicionados à lista e exibidos na tela.
        
        Args:
            configuracoes (list): Lista de dicionários com as configurações dos marcadores.
                Cada dicionário contém os parâmetros necessários para recriar um marcador
                exatamente como estava quando foi salvo.
        """
        for config in configuracoes:
            tecla = config.get("tecla", "a")
            tipo = config.get("tipo", "Clique Esquerdo")
            cor = config.get("cor", "#3498db")
            tamanho = config.get("tamanho", 30)
            visibilidade = config.get("visibilidade", 0.5)
            posicao = config.get("posicao", [100, 100])
            
            # Criar o marcador apropriado
            if tipo == "Clique Esquerdo":
                marcador = MarcadorCliqueEsquerdo(tecla, posicao, cor, tamanho, visibilidade)
            else:  # Clique Direito
                marcador = MarcadorCliqueDireito(tecla, posicao, cor, tamanho, visibilidade)
            
            # Adicionar à lista de marcadores
            self.marcadores.append(marcador)
            
            # Mostrar o marcador
            marcador.show()
        
        # Atualizar a lista na interface
        self.atualizar_lista_marcadores()
    
    def salvar_configuracoes(self):
        """Salva as configurações dos marcadores.
        
        Coleta as configurações atuais de todos os marcadores (tecla, tipo, cor,
        tamanho, visibilidade e posição) e as salva usando o gerenciador de
        configurações. Exibe uma mensagem informando o resultado da operação
        (sucesso ou erro).
        
        As configurações são salvas em formato JSON através do gerenciador de
        configurações, permitindo que sejam carregadas em execuções futuras
        do aplicativo.
        """
        configuracoes = []
        
        for marcador in self.marcadores:
            config = {
                "tecla": marcador.tecla,
                "tipo": "Clique Esquerdo" if isinstance(marcador, MarcadorCliqueEsquerdo) else "Clique Direito",
                "cor": marcador.cor,
                "tamanho": marcador.tamanho,
                "visibilidade": marcador.visibilidade,
                "posicao": [marcador.pos().x(), marcador.pos().y()]
            }
            configuracoes.append(config)
        
        # Salvar usando o gerenciador de configurações
        if self.gerenciador_config.salvar_configuracoes(configuracoes):
            QMessageBox.information(self, "Sucesso", "Configurações salvas com sucesso!")
        else:
            QMessageBox.warning(self, "Erro", "Erro ao salvar configurações.")
    
    def mostrar(self):
        """Mostra a janela principal e todos os marcadores.
        
        Exibe a janela principal da aplicação e todos os marcadores ativos.
        Este método é chamado quando o usuário clica na opção "Mostrar" no
        menu de contexto do ícone na bandeja do sistema.
        """
        self.show()
        for marcador in self.marcadores:
            marcador.show()
    
    def sair(self):
        """Encerra a aplicação.
        
        Pergunta ao usuário se deseja salvar as configurações antes de sair,
        fecha todos os marcadores e encerra a aplicação. Este método é chamado
        quando o usuário clica na opção "Sair" no menu de contexto do ícone
        na bandeja do sistema.
        
        O usuário pode escolher entre salvar as configurações, sair sem salvar
        ou cancelar a operação.
        """
        # Perguntar se deseja salvar antes de sair
        resposta = QMessageBox.question(self, "Sair", "Deseja salvar as configurações antes de sair?",
                                       QMessageBox.Yes | QMessageBox.No | QMessageBox.Cancel)
        
        if resposta == QMessageBox.Cancel:
            return
        
        if resposta == QMessageBox.Yes:
            self.salvar_configuracoes()
        
        # Fechar todos os marcadores
        for marcador in self.marcadores:
            marcador.close()
        
        # Fechar a aplicação
        QApplication.quit()
    
    def closeEvent(self, event):
        """Manipula o evento de fechar a janela.
        
        Sobrescreve o comportamento padrão do evento de fechar a janela para
        apenas ocultar a janela em vez de encerrar a aplicação. Isso permite
        que o aplicativo continue rodando em segundo plano com o ícone na
        bandeja do sistema, mesmo quando a janela principal está fechada.
        
        Args:
            event (QCloseEvent): Evento de fechar gerado pelo sistema quando
                o usuário tenta fechar a janela principal.
        """
        # Apenas esconder a janela em vez de fechar a aplicação
        event.ignore()
        self.hide()