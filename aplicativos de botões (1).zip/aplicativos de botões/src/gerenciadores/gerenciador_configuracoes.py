# Importações de bibliotecas padrão
import json  # Para serialização e deserialização de dados em formato JSON
import os    # Para operações de sistema de arquivos

class GerenciadorConfiguracoes:
    """Classe responsável por gerenciar o salvamento e carregamento das configurações dos marcadores.
    
    Implementa funcionalidades para salvar e carregar as configurações dos marcadores
    em um arquivo JSON, garantindo a persistência das configurações entre execuções.
    
    Esta classe é responsável por:
    - Definir o local de armazenamento das configurações
    - Garantir que o diretório de configurações exista
    - Serializar as configurações dos marcadores em formato JSON
    - Deserializar as configurações salvas para recriar os marcadores
    - Tratar erros durante as operações de leitura e escrita
    """
    
    def __init__(self, nome_arquivo="configuracoes_botoes.json"):
        """Inicializa o gerenciador de configurações.
        
        Configura o caminho do arquivo de configurações e garante que o diretório
        necessário exista. O arquivo será criado no subdiretório 'config' do
        diretório raiz do projeto.
        
        Args:
            nome_arquivo (str): Nome do arquivo de configurações. Por padrão,
                usa 'configuracoes_botoes.json'.
        """
        self.nome_arquivo = nome_arquivo
        self.caminho_arquivo = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "config", nome_arquivo)
        
        # Garantir que o diretório de configurações existe
        os.makedirs(os.path.dirname(self.caminho_arquivo), exist_ok=True)
    
    def salvar_configuracoes(self, configuracoes):
        """Salva as configurações dos marcadores em um arquivo JSON.
        
        Serializa a lista de configurações em formato JSON e a salva no arquivo
        definido durante a inicialização. Captura e registra quaisquer erros
        que ocorram durante o processo.
        
        Args:
            configuracoes (list): Lista de dicionários com as configurações dos marcadores.
                Cada dicionário contém atributos como tecla, tipo, cor, tamanho,
                visibilidade e posição de um marcador.
            
        Returns:
            bool: True se o salvamento foi bem-sucedido, False caso contrário
        """
        try:
            with open(self.caminho_arquivo, "w") as arquivo:
                json.dump(configuracoes, arquivo)
            return True
        except Exception as e:
            print(f"Erro ao salvar configurações: {e}")
            return False
    
    def carregar_configuracoes(self):
        """Carrega as configurações dos marcadores a partir do arquivo JSON.
        
        Verifica se o arquivo de configurações existe e, em caso afirmativo,
        deserializa seu conteúdo JSON para obter a lista de configurações dos
        marcadores. Se o arquivo não existir ou ocorrer algum erro durante a
        leitura, retorna uma lista vazia.
        
        Returns:
            list: Lista de dicionários com as configurações dos marcadores.
                Cada dicionário contém os parâmetros necessários para recriar
                um marcador como estava quando foi salvo.
        """
        try:
            if os.path.exists(self.caminho_arquivo):
                with open(self.caminho_arquivo, "r") as arquivo:
                    return json.load(arquivo)
            return []
        except Exception as e:
            print(f"Erro ao carregar configurações: {e}")
            return []