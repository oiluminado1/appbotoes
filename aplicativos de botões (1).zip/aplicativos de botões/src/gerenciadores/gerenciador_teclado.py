#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Importações de bibliotecas padrão
import threading  # Para execução em threads paralelas
import time       # Para controle de tempo entre acionamentos
from pynput import keyboard  # Para captura de eventos de teclado em segundo plano

class GerenciadorTeclado:
    """Classe responsável por gerenciar a captura de eventos de teclado.
    
    Implementa a captura de teclas de atalho e aciona os marcadores correspondentes.
    Utiliza a biblioteca pynput para captura de teclas em segundo plano.
    
    Esta classe é responsável por:
    - Monitorar eventos de teclado em uma thread separada
    - Identificar quando teclas de atalho são pressionadas
    - Acionar os marcadores correspondentes às teclas pressionadas
    - Controlar o tempo entre acionamentos consecutivos (cooldown)
    - Converter eventos de teclado em um formato padronizado
    """
    
    def __init__(self, interface):
        """Inicializa o gerenciador de teclado.
        
        Configura os atributos necessários para o funcionamento do gerenciador,
        incluindo a referência para a interface gráfica, estruturas para controle
        de teclas pressionadas e tempo entre acionamentos.
        
        Args:
            interface (InterfaceGrafica): Referência para a interface gráfica que
                contém a lista de marcadores a serem acionados pelas teclas de atalho
        """
        self.interface = interface
        self.listener = None
        self.thread_captura = None
        self.executando = False
        self.teclas_pressionadas = set()
        
        # Tempo mínimo entre acionamentos consecutivos (em segundos)
        self.tempo_cooldown = 0.2
        self.ultimo_acionamento = {}
    
    def iniciar_captura(self):
        """Inicia a captura de teclas em uma thread separada.
        
        Cria e inicia uma thread dedicada para monitorar eventos de teclado
        em segundo plano, permitindo que o usuário acione os marcadores
        mesmo quando a janela principal não está em foco.
        
        Se a captura já estiver em andamento, não faz nada.
        """
        if self.executando:
            return
        
        self.executando = True
        self.thread_captura = threading.Thread(target=self._loop_captura, daemon=True)
        self.thread_captura.start()
    
    def parar_captura(self):
        """Para a captura de teclas.
        
        Interrompe o monitoramento de eventos de teclado, sinalizando para
        a thread de captura que deve encerrar e parando o listener de teclado.
        """
        self.executando = False
        if self.listener:
            self.listener.stop()
    
    def _loop_captura(self):
        """Loop principal de captura de teclas.
        
        Método executado na thread de captura. Cria um listener de teclado
        que monitora eventos de pressionar e soltar teclas, chamando os
        callbacks apropriados para cada evento.
        
        O listener é executado até que o método parar_captura() seja chamado
        ou a aplicação seja encerrada.
        """
        with keyboard.Listener(
            on_press=self._ao_pressionar,
            on_release=self._ao_soltar
        ) as self.listener:
            self.listener.join()
    
    def _ao_pressionar(self, tecla):
        """Callback chamado quando uma tecla é pressionada.
        
        Converte a tecla para um formato padronizado, adiciona-a ao conjunto
        de teclas pressionadas e verifica se corresponde a algum atalho de
        marcador. Em caso afirmativo, aciona o marcador correspondente,
        respeitando o tempo de cooldown entre acionamentos.
        
        Args:
            tecla (keyboard.Key ou keyboard.KeyCode): Tecla pressionada pelo usuário,
                pode ser uma tecla especial (Shift, Ctrl, etc.) ou uma tecla comum
        """
        try:
            # Converter a tecla para um formato padronizado
            tecla_str = self._converter_tecla(tecla)
            if not tecla_str:
                return
            
            # Adicionar à lista de teclas pressionadas
            self.teclas_pressionadas.add(tecla_str)
            
            # Verificar se é uma tecla de atalho para algum marcador
            self._verificar_atalhos(tecla_str)
            
        except Exception as e:
            print(f"Erro ao processar tecla pressionada: {e}")
    
    def _ao_soltar(self, tecla):
        """Callback chamado quando uma tecla é solta.
        
        Converte a tecla para um formato padronizado e a remove do conjunto
        de teclas pressionadas. Isso permite rastrear quais teclas estão
        atualmente pressionadas para implementar combinações de teclas
        no futuro, se necessário.
        
        Args:
            tecla (keyboard.Key ou keyboard.KeyCode): Tecla solta pelo usuário,
                pode ser uma tecla especial (Shift, Ctrl, etc.) ou uma tecla comum
        """
        try:
            # Converter a tecla para um formato padronizado
            tecla_str = self._converter_tecla(tecla)
            if not tecla_str:
                return
            
            # Remover da lista de teclas pressionadas
            if tecla_str in self.teclas_pressionadas:
                self.teclas_pressionadas.remove(tecla_str)
                
        except Exception as e:
            print(f"Erro ao processar tecla solta: {e}")
    
    def _converter_tecla(self, tecla):
        """Converte uma tecla para um formato padronizado.
        
        Transforma os diferentes tipos de teclas (teclas especiais e teclas comuns)
        em uma representação de string padronizada. Isso permite comparar facilmente
        as teclas pressionadas com as teclas de atalho dos marcadores.
        
        Args:
            tecla (keyboard.Key ou keyboard.KeyCode): Tecla a ser convertida,
                pode ser uma tecla especial (representada como keyboard.Key)
                ou uma tecla comum (representada como keyboard.KeyCode)
            
        Returns:
            str: Representação da tecla em formato de string
        """
        try:
            # Se for uma tecla especial (Shift, Ctrl, etc.)
            if hasattr(tecla, 'name'):
                return tecla.name.lower()
            
            # Se for uma tecla normal (letra, número, etc.)
            if hasattr(tecla, 'char'):
                return tecla.char.lower()
            
            # Caso não seja possível determinar
            return None
            
        except Exception:
            return None
    
    def _verificar_atalhos(self, tecla):
        """Verifica se a tecla pressionada corresponde a algum atalho de marcador.
        
        Args:
            tecla (str): Tecla pressionada em formato de string
        """
        # Verificar cooldown para evitar acionamentos múltiplos rápidos
        tempo_atual = time.time()
        if tecla in self.ultimo_acionamento and \
           (tempo_atual - self.ultimo_acionamento[tecla]) < self.tempo_cooldown:
            return
        
        # Atualizar o tempo do último acionamento
        self.ultimo_acionamento[tecla] = tempo_atual
        
        # Verificar se a tecla corresponde a algum marcador
        for marcador in self.interface.marcadores:
            if marcador.tecla == tecla:
                # Acionar o marcador em uma thread separada para não bloquear a captura de teclas
                threading.Thread(target=marcador.simular_clique, daemon=True).start()
                break