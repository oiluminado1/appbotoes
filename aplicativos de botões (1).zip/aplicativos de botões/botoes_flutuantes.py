import sys
import json
import os
from PyQt5.QtWidgets import (QApplication, QMainWindow, QPushButton, QVBoxLayout, 
                             QHBoxLayout, QWidget, QLabel, QLineEdit, QComboBox, 
                             QColorDialog, QMessageBox, QListWidget, QListWidgetItem,
                             QCheckBox, QSlider)
from PyQt5.QtCore import Qt, QPoint, pyqtSignal, QObject
from PyQt5.QtGui import QFont, QColorq
import pyautogui
from pynput import keyboard

# Classe para o marcador de posição (substitui o botão flutuante)
class MarcadorPosicao(QWidget):
    def __init__(self, tecla, posicao, cor="#3498db", tamanho=30, visibilidade=0.5, botao_mouse="left"):
        super().__init__()
        self.tecla = tecla.lower()
        self.posicao_original = posicao
        self.tamanho = tamanho
        self.cor = cor
        self.visibilidade = visibilidade
        self.botao_mouse = botao_mouse  # Novo parâmetro para definir qual botão do mouse simular
        
        # Configurar a aparência do marcador
        self.setGeometry(posicao[0], posicao[1], tamanho, tamanho)
        self.setStyleSheet(f"background-color: {cor}; border-radius: {tamanho//2}px;")
        # Ajustar flags para garantir que o marcador fique sobre outras janelas e não interfira com o foco
        self.setWindowFlags(Qt.WindowStaysOnTopHint | Qt.FramelessWindowHint | Qt.Tool | Qt.WindowDoesNotAcceptFocus)
        # Permitir que cliques passem através do widget
        self.setAttribute(Qt.WA_TransparentForMouseEvents)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setFixedSize(tamanho, tamanho)
        self.setWindowOpacity(visibilidade)
        
        # Variáveis para controlar o arrasto do marcador
        self.dragging = False
        self.offset = QPoint()
        
        # Adicionar texto da tecla no centro
        # Mapear teclas especiais para símbolos visuais
        simbolos_teclas = {
            'up': '↑',
            'down': '↓',
            'left': '←',
            'right': '→',
            'space': '␣',
            'enter': '↵',
            'esc': 'Esc'
        }
        
        # Verificar se é uma tecla especial ou alfanumérica
        texto_exibido = simbolos_teclas.get(tecla, tecla.upper())
        
        self.texto = QLabel(texto_exibido, self)
        self.texto.setAlignment(Qt.AlignCenter)
        self.texto.setStyleSheet("color: white; font-weight: bold;")
        self.texto.setGeometry(0, 0, tamanho, tamanho)
    
    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.dragging = True
            self.offset = event.pos()
        else:
            super().mousePressEvent(event)
    
    def mouseMoveEvent(self, event):
        if self.dragging and event.buttons() & Qt.LeftButton:
            self.move(self.mapToParent(event.pos() - self.offset))
        else:
            super().mouseMoveEvent(event)
    
    def mouseReleaseEvent(self, event):
        if self.dragging and event.button() == Qt.LeftButton:
            self.dragging = False
            # Atualizar a posição original após o arrasto
            self.posicao_original = [self.x(), self.y()]
        else:
            super().mouseReleaseEvent(event)
    
    def simular_clique(self):
        # Simular um clique na posição do marcador
        try:
            # Obter a posição global do widget na tela
            pos_global = self.mapToGlobal(QPoint(self.width() // 2, self.height() // 2))
            pos_x = pos_global.x()
            pos_y = pos_global.y()
            
            print(f"Simulando clique na posição: ({pos_x}, {pos_y}) com botão {self.botao_mouse}")
            
            # Método simplificado usando ctypes para Windows
            import ctypes
            import time
            
            # Definir constantes para a API do Windows
            MOUSEEVENTF_LEFTDOWN = 0x0002
            MOUSEEVENTF_LEFTUP = 0x0004
            MOUSEEVENTF_RIGHTDOWN = 0x0008
            MOUSEEVENTF_RIGHTUP = 0x0010
            
            # Salvar posição atual do cursor
            class POINT(ctypes.Structure):
                _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]
            
            pt = POINT()
            ctypes.windll.user32.GetCursorPos(ctypes.byref(pt))
            old_x, old_y = pt.x, pt.y
            
            # Mover o cursor para a posição do marcador
            ctypes.windll.user32.SetCursorPos(pos_x, pos_y)
            time.sleep(0.1)  # Pequena pausa para garantir que o cursor chegou à posição
            
            # Simular o clique do botão do mouse
            if self.botao_mouse == "left":
                # Clique esquerdo
                ctypes.windll.user32.mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0)
                time.sleep(0.05)
                ctypes.windll.user32.mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0)
                print("Clique com botão esquerdo realizado")
            
            elif self.botao_mouse == "right":
                # Clique direito
                ctypes.windll.user32.mouse_event(MOUSEEVENTF_RIGHTDOWN, 0, 0, 0, 0)
                time.sleep(0.05)
                ctypes.windll.user32.mouse_event(MOUSEEVENTF_RIGHTUP, 0, 0, 0, 0)
                print("Clique com botão direito realizado")
            
            # Restaurar a posição original do cursor (opcional, remova se preferir manter o cursor na posição do clique)
            # ctypes.windll.user32.SetCursorPos(old_x, old_y)
            
        except Exception as e:
            print(f"Erro ao simular clique: {e}")
            import traceback
            traceback.print_exc()
            
            # Método alternativo com pyautogui como fallback
            try:
                print("Tentando método alternativo com pyautogui...")
                import pyautogui
                pyautogui.FAILSAFE = False
                pyautogui.moveTo(pos_x, pos_y, duration=0.1)
                pyautogui.click(button=self.botao_mouse)
                print(f"Clique alternativo realizado com pyautogui")
            except Exception as e2:
                print(f"Erro também no método alternativo: {e2}")
                traceback.print_exc()
        
    def atualizar_visibilidade(self, valor):
        self.visibilidade = valor
        self.setWindowOpacity(valor)

# Classe principal da aplicação
class GerenciadorBotoes(QMainWindow):
    def __init__(self):
        super().__init__()
        self.marcadores_ativos = []
        self.configuracoes_marcadores = []
        # Adicionar teclas especiais à lista de teclas disponíveis
        self.teclas_alfanumericas = ['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p']
        self.teclas_especiais = {
            'up': 'Seta ↑',
            'down': 'Seta ↓',
            'left': 'Seta ←',
            'right': 'Seta →',
            'space': 'Espaço',
            'enter': 'Enter',
            'esc': 'Esc'
        }
        self.teclas_disponiveis = self.teclas_alfanumericas.copy()
        self.listener = None
        self.inicializar_ui()
        self.carregar_configuracoes()
        self.iniciar_listener_teclado()
    
    def inicializar_ui(self):
        self.setWindowTitle("Teclas para Jogos")
        self.setGeometry(100, 100, 600, 450)
        
        # Widget central e layout principal
        widget_central = QWidget()
        layout_principal = QVBoxLayout(widget_central)
        
        # Seção de criação de marcadores
        grupo_criacao = QWidget()
        layout_criacao = QVBoxLayout(grupo_criacao)
        
        # Tecla de atalho
        layout_tecla = QHBoxLayout()
        label_tecla = QLabel("Tecla de atalho:")
        self.combo_tecla = QComboBox()
        
        # Adicionar teclas alfanuméricas
        for tecla in self.teclas_alfanumericas:
            self.combo_tecla.addItem(tecla.upper())
            
        # Adicionar separador
        self.combo_tecla.insertSeparator(len(self.teclas_alfanumericas))
        
        # Adicionar teclas especiais
        for codigo, nome in self.teclas_especiais.items():
            self.combo_tecla.addItem(nome, codigo)
            
        layout_tecla.addWidget(label_tecla)
        layout_tecla.addWidget(self.combo_tecla)
        layout_criacao.addLayout(layout_tecla)
        
        # Cor do marcador
        layout_cor = QHBoxLayout()
        label_cor = QLabel("Cor do marcador:")
        self.botao_cor = QPushButton()
        self.botao_cor.setStyleSheet("background-color: #3498db;")
        self.botao_cor.setFixedSize(30, 20)
        self.cor_atual = "#3498db"
        self.botao_cor.clicked.connect(self.selecionar_cor)
        layout_cor.addWidget(label_cor)
        layout_cor.addWidget(self.botao_cor)
        layout_criacao.addLayout(layout_cor)
        
        # Tamanho do marcador
        layout_tamanho = QHBoxLayout()
        label_tamanho = QLabel("Tamanho do marcador:")
        self.combo_tamanho = QComboBox()
        for tamanho in [20, 30, 40, 50, 60]:
            self.combo_tamanho.addItem(str(tamanho))
        self.combo_tamanho.setCurrentIndex(1)  # Padrão: 30
        layout_tamanho.addWidget(label_tamanho)
        layout_tamanho.addWidget(self.combo_tamanho)
        layout_criacao.addLayout(layout_tamanho)
        
        # Visibilidade dos marcadores
        layout_visibilidade = QHBoxLayout()
        label_visibilidade = QLabel("Visibilidade:")
        self.slider_visibilidade = QSlider(Qt.Horizontal)
        self.slider_visibilidade.setMinimum(0)
        self.slider_visibilidade.setMaximum(100)
        self.slider_visibilidade.setValue(50)  # 50% de visibilidade por padrão
        self.slider_visibilidade.valueChanged.connect(self.atualizar_visibilidade_todos)
        layout_visibilidade.addWidget(label_visibilidade)
        layout_visibilidade.addWidget(self.slider_visibilidade)
        layout_criacao.addLayout(layout_visibilidade)
        
        # Botão do mouse a simular
        layout_botao_mouse = QHBoxLayout()
        label_botao_mouse = QLabel("Botão do mouse:")
        self.combo_botao_mouse = QComboBox()
        self.combo_botao_mouse.addItem("Botão Esquerdo", "left")
        self.combo_botao_mouse.addItem("Botão Direito", "right")
        layout_botao_mouse.addWidget(label_botao_mouse)
        layout_botao_mouse.addWidget(self.combo_botao_mouse)
        layout_criacao.addLayout(layout_botao_mouse)
        
        # Botão para criar
        self.botao_criar = QPushButton("Criar Marcador")
        self.botao_criar.clicked.connect(self.criar_marcador)
        layout_criacao.addWidget(self.botao_criar)
        
        # Lista de marcadores criados
        self.lista_marcadores = QListWidget()
        self.lista_marcadores.setMinimumHeight(150)
        
        # Botões para gerenciar a lista
        layout_gerenciar = QHBoxLayout()
        self.botao_mostrar_todos = QPushButton("Mostrar Todos")
        self.botao_mostrar_todos.clicked.connect(self.mostrar_todos_marcadores)
        self.botao_ocultar_todos = QPushButton("Ocultar Todos")
        self.botao_ocultar_todos.clicked.connect(self.ocultar_todos_marcadores)
        self.botao_remover = QPushButton("Remover Selecionado")
        self.botao_remover.clicked.connect(self.remover_marcador_selecionado)
        layout_gerenciar.addWidget(self.botao_mostrar_todos)
        layout_gerenciar.addWidget(self.botao_ocultar_todos)
        layout_gerenciar.addWidget(self.botao_remover)
        
        # Adicionar todos os componentes ao layout principal
        layout_principal.addWidget(grupo_criacao)
        layout_principal.addWidget(QLabel("Marcadores criados:"))
        layout_principal.addWidget(self.lista_marcadores)
        layout_principal.addLayout(layout_gerenciar)
        
        # Definir o widget central
        self.setCentralWidget(widget_central)
        
        # Instruções
        instrucoes = QLabel("Instruções: Pressione a tecla configurada (Q, W, E, R, etc. ou teclas especiais) para simular um clique\n"
                           "na posição do marcador. Arraste os marcadores para posicionar.")
        instrucoes.setAlignment(Qt.AlignCenter)
        layout_principal.addWidget(instrucoes)
    
    def selecionar_cor(self):
        cor = QColorDialog.getColor((self.cor_atual), self)
        if cor.isValid():
            self.cor_atual = cor.name()
            self.botao_cor.setStyleSheet(f"background-color: {self.cor_atual};")
    
    def criar_marcador(self):
        # Verificar se é uma tecla especial ou alfanumérica
        indice = self.combo_tecla.currentIndex()
        if indice < len(self.teclas_alfanumericas):
            # É uma tecla alfanumérica
            tecla = self.combo_tecla.currentText().lower()
        else:
            # É uma tecla especial, obter o código da tecla
            tecla = self.combo_tecla.currentData()
        
        tamanho = int(self.combo_tamanho.currentText())
        
        # Posição inicial no centro da tela
        screen_geometry = QApplication.desktop().screenGeometry()
        posicao = [screen_geometry.width() // 2, screen_geometry.height() // 2]
        
        # Obter a visibilidade atual
        visibilidade = self.slider_visibilidade.value() / 100.0
        
        # Obter o botão do mouse selecionado
        botao_mouse = self.combo_botao_mouse.currentData()
        
        # Criar e mostrar o marcador de posição
        marcador = MarcadorPosicao(tecla, posicao, self.cor_atual, tamanho, visibilidade, botao_mouse)
        marcador.show()
        
        # Adicionar à lista de marcadores ativos
        self.marcadores_ativos.append(marcador)
        
        # Adicionar à lista de configurações para salvar depois
        config = {
            "tecla": tecla,
            "posicao": posicao,
            "cor": self.cor_atual,
            "tamanho": tamanho,
            "visibilidade": visibilidade,
            "botao_mouse": botao_mouse
        }
        self.configuracoes_marcadores.append(config)        
        # Adicionar à lista visual com nome apropriado para teclas especiais
        nome_tecla = tecla.upper()
        if tecla in self.teclas_especiais:
            nome_tecla = self.teclas_especiais[tecla]
            
        # Texto do botão do mouse para exibição
        texto_botao = "Botão Direito" if botao_mouse == "right" else "Botão Esquerdo"
        item = QListWidgetItem(f"Tecla {nome_tecla} - {self.cor_atual} - Tamanho: {tamanho} - {texto_botao}")
        self.lista_marcadores.addItem(item)
        
        # Salvar configurações
        self.salvar_configuracoes()
    
    def mostrar_todos_marcadores(self):
        for marcador in self.marcadores_ativos:
            marcador.show()
    
    def ocultar_todos_marcadores(self):
        for marcador in self.marcadores_ativos:
            marcador.hide()
    
    def atualizar_visibilidade_todos(self, valor):
        visibilidade = valor / 100.0
        for marcador in self.marcadores_ativos:
            marcador.atualizar_visibilidade(visibilidade)
    
    def remover_marcador_selecionado(self):
        indice_selecionado = self.lista_marcadores.currentRow()
        if indice_selecionado >= 0:
            # Remover da interface
            if indice_selecionado < len(self.marcadores_ativos):
                self.marcadores_ativos[indice_selecionado].close()
                self.marcadores_ativos.pop(indice_selecionado)
            
            # Remover da lista de configurações
            if indice_selecionado < len(self.configuracoes_marcadores):
                self.configuracoes_marcadores.pop(indice_selecionado)
            
            # Remover da lista visual
            self.lista_marcadores.takeItem(indice_selecionado)
            
            # Salvar configurações
            self.salvar_configuracoes()
    
    def salvar_configuracoes(self):
        # Atualizar as posições dos marcadores antes de salvar
        for i, marcador in enumerate(self.marcadores_ativos):
            if i < len(self.configuracoes_marcadores):
                self.configuracoes_marcadores[i]["posicao"] = [marcador.x(), marcador.y()]
                self.configuracoes_marcadores[i]["visibilidade"] = marcador.visibilidade
        
        # Salvar no arquivo
        try:
            caminho_arquivo = os.path.join(os.path.dirname(os.path.abspath(__file__)), "configuracoes_botoes.json")
            with open(caminho_arquivo, "w") as arquivo:
                json.dump(self.configuracoes_marcadores, arquivo)
        except Exception as e:
            print(f"Erro ao salvar configurações: {e}")
    
    def carregar_configuracoes(self):
        try:
            caminho_arquivo = os.path.join(os.path.dirname(os.path.abspath(__file__)), "configuracoes_botoes.json")
            if os.path.exists(caminho_arquivo):
                with open(caminho_arquivo, "r") as arquivo:
                    self.configuracoes_marcadores = json.load(arquivo)
                
                # Criar marcadores a partir das configurações carregadas
                for config in self.configuracoes_marcadores:
                    # Obter a tecla de atalho (verificar tanto 'tecla' quanto 'texto' para compatibilidade)
                    tecla = config.get("tecla", config.get("texto", "q"))
                    # Corrigir a configuração para usar sempre 'tecla'
                    if "texto" in config and "tecla" not in config:
                        config["tecla"] = config.pop("texto")
                    # Obter a visibilidade ou usar o padrão
                    visibilidade = config.get("visibilidade", 0.5)
                    # Obter o botão do mouse ou usar o padrão (botão esquerdo)
                    botao_mouse = config.get("botao_mouse", "left")
                    
                    marcador = MarcadorPosicao(
                        tecla,
                        config["posicao"],
                        config["cor"],
                        config["tamanho"],
                        visibilidade,
                        botao_mouse
                    )
                    marcador.show()
                    self.marcadores_ativos.append(marcador)
                    
                    # Adicionar à lista visual com nome apropriado para teclas especiais
                    nome_tecla = tecla.upper()
                    if tecla in self.teclas_especiais:
                        nome_tecla = self.teclas_especiais[tecla]
                    
                    # Texto do botão do mouse para exibição
                    texto_botao = "Botão Direito" if config.get("botao_mouse") == "right" else "Botão Esquerdo"
                    item = QListWidgetItem(f"Tecla {nome_tecla} - {config['cor']} - Tamanho: {config['tamanho']} - {texto_botao}")
                    self.lista_marcadores.addItem(item)
                    
                # Atualizar o slider de visibilidade se houver marcadores
                if self.marcadores_ativos and "visibilidade" in self.configuracoes_marcadores[0]:
                    self.slider_visibilidade.setValue(int(self.configuracoes_marcadores[0]["visibilidade"] * 100))
        except Exception as e:
            print(f"Erro ao carregar configurações: {e}")
    
    def iniciar_listener_teclado(self):
        # Função para processar teclas pressionadas
        def on_press(key):
            try:
                tecla_str = ''
                
                # Verificar se é uma tecla alfanumérica
                if hasattr(key, 'char'):
                    tecla_str = key.char.lower() if key.char else ''
                # Verificar se é uma tecla especial
                else:
                    # Mapear teclas especiais para seus códigos
                    teclas_mapeadas = {
                        keyboard.Key.up: 'up',
                        keyboard.Key.down: 'down',
                        keyboard.Key.left: 'left',
                        keyboard.Key.right: 'right',
                        keyboard.Key.space: 'space',
                        keyboard.Key.enter: 'enter',
                        keyboard.Key.esc: 'esc'
                    }
                    
                    if key in teclas_mapeadas:
                        tecla_str = teclas_mapeadas[key]
                
                if tecla_str:
                    print(f"Tecla pressionada: {tecla_str}")
                    for marcador in self.marcadores_ativos:
                        if marcador.tecla == tecla_str:
                            # Garantir que o marcador esteja visível antes de simular o clique
                            if marcador.isVisible():
                                print(f"Simulando clique para tecla: {tecla_str}")
                                marcador.simular_clique()
            except Exception as e:
                print(f"Erro ao processar tecla: {e}")
                import traceback
                traceback.print_exc()
        
        # Iniciar o listener de teclado em segundo plano com supressão desativada
        # para não interferir com outros aplicativos
        self.listener = keyboard.Listener(on_press=on_press, suppress=False)
        self.listener.daemon = True  # Garantir que o listener termine quando o programa terminar
        self.listener.start()
        print("Listener de teclado iniciado com sucesso!")
    
    def closeEvent(self, event):
        # Salvar configurações antes de fechar
        self.salvar_configuracoes()
        
        # Parar o listener de teclado
        if self.listener:
            self.listener.stop()
        
        # Fechar todos os marcadores
        for marcador in self.marcadores_ativos:
            marcador.close()
        
        event.accept()

# Iniciar a aplicação
if __name__ == "__main__":
    app = QApplication(sys.argv)
    janela = GerenciadorBotoes()
    janela.show()
    sys.exit(app.exec_())